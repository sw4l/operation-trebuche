class CfgPatches
{
	class OPTRE_Misc_Objects
	{
		units[]										= {"OPTRE_Objects_ODST_Grave","OPTRE_Objects_Soldier_Grave","OPTRE_Objects_Monument","OPTRE_Objects_Kiosk1","OPTRE_Objects_Kiosk2","OPTRE_Objects_Kiosk3","OPTRE_Objects_Holotable_Blank","OPTRE_Objects_Holotable_Altis","OPTRE_Objects_Holotable_Stratis"};
		weapons[]									= {};
		requiredVersion								= 0.1;
		requiredAddons[]							= {"OPTRE_Core","OPTRE_Weapons","OPTRE_UNSC_Units","OPTRE_Ins_Units"};
	};
};

class CfgVehicles
{
	class OPTRE_Objects_Base;
	
	class OPTRE_FC_Energy_shield: OPTRE_Objects_Base
	{
		dlc = "OPTRE";
		scope = 2;
		scopeCurator = 2;
		displayName = "Energy Shield";
		model = "\OPTRE_FC\Energy_shield.p3d";
		author = "Article 2 Studios";
	};
};
